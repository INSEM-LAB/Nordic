/*
 * Copyright (c) 2018 Nordic Semiconductor ASA
 *
 * SPDX-License-Identifier: LicenseRef-Nordic-5-Clause
 */

/** @file
 *  @brief Nordic UART Bridge Service (NUS) sample
 */
#include "uart_async_adapter.h"

#include <zephyr/types.h>
#include <zephyr/kernel.h>
#include <zephyr/drivers/uart.h>
#include <zephyr/usb/usb_device.h>

#include <zephyr/device.h>
#include <zephyr/devicetree.h>
#include <soc.h>

#include <zephyr/bluetooth/bluetooth.h>
#include <zephyr/bluetooth/uuid.h>
#include <zephyr/bluetooth/gatt.h>
#include <zephyr/bluetooth/hci.h>

#include <bluetooth/services/nus.h>

#include <dk_buttons_and_leds.h>

#include <zephyr/settings/settings.h>

#include <stdio.h>

#include <zephyr/logging/log.h>

#include <zephyr/sys/ring_buffer.h>
#include "shell_ipc_host.h"
#include <zephyr/ipc/ipc_service.h>
#include <zephyr/drivers/gpio.h>
#include <string.h>

#define LOG_MODULE_NAME peripheral_uart
LOG_MODULE_REGISTER(LOG_MODULE_NAME);

#define STACKSIZE CONFIG_BT_NUS_THREAD_STACK_SIZE
#define PRIORITY 7

#define DEVICE_NAME CONFIG_BT_DEVICE_NAME
#define DEVICE_NAME_LEN	(sizeof(DEVICE_NAME) - 1)

#define RUN_STATUS_LED DK_LED1
#define RUN_LED_BLINK_INTERVAL 1000

#define CON_STATUS_LED DK_LED2

#define KEY_PASSKEY_ACCEPT DK_BTN1_MSK
#define KEY_PASSKEY_REJECT DK_BTN2_MSK

#define UART_BUF_SIZE CONFIG_BT_NUS_UART_BUFFER_SIZE
#define UART_WAIT_FOR_BUF_DELAY K_MSEC(50)
#define UART_WAIT_FOR_RX CONFIG_BT_NUS_UART_RX_WAIT_TIME
#define MSG_SIZE 8

static K_SEM_DEFINE(ble_init_ok, 0, 1);

static struct bt_conn *current_conn;
static struct bt_conn *auth_conn;

static const struct device *nus_uart = DEVICE_DT_GET(DT_CHOSEN(nordic_nus_uart));
/* queue to store up to 10 messages (aligned to 4-byte boundary) */
K_MSGQ_DEFINE(uart_msgq, MSG_SIZE, 10, 4);
/* receive buffer used in UART ISR callback */
static char rx_buf[MSG_SIZE];
static int rx_buf_pos;

static const struct bt_data ad[] = {
	BT_DATA_BYTES(BT_DATA_FLAGS, (BT_LE_AD_GENERAL | BT_LE_AD_NO_BREDR)),
	BT_DATA(BT_DATA_NAME_COMPLETE, DEVICE_NAME, DEVICE_NAME_LEN),
};

static const struct bt_data sd[] = {
	BT_DATA_BYTES(BT_DATA_UUID128_ALL, BT_UUID_NUS_VAL),
};

static bool dtm_ready = false;

/* it's used to add remote shell function */
#define HOST_WAIT_TIME 1000000

RING_BUF_DECLARE(rx_ringbuf, CONFIG_REMOTE_SHELL_RX_RING_BUFFER_SIZE);
RING_BUF_DECLARE(tx_ringbuf, CONFIG_REMOTE_SHELL_TX_RING_BUFFER_SIZE);

K_SEM_DEFINE(shell_ipc_write_sem, 0, 1);

static const struct uart_irq_context {
	struct ring_buf *rx_buf;
	struct ring_buf *tx_buf;
	struct k_sem *write_sem;
} uart_context = {
	.rx_buf = &rx_ringbuf,
	.tx_buf = &tx_ringbuf,
	.write_sem = &shell_ipc_write_sem
};

/*
 * Read characters from UART until line end is detected. Afterwards push the
 * data to the message queue.
 */
void nus_serial_cb(const struct device *dev, void *user_data)
{
	uint8_t c;

	if (!uart_irq_update(nus_uart)) {
		return;
	}

	if (!uart_irq_rx_ready(nus_uart)) {
		return;
	}

	/* read until FIFO empty */
	while (uart_fifo_read(nus_uart, &c, 1) == 1) {
		if ((c == '\n' || c == '\r') && rx_buf_pos > 0) {
			/* terminate string */
			rx_buf[rx_buf_pos] = '\0';

			/* if queue is full, message is silently dropped */
			k_msgq_put(&uart_msgq, &rx_buf, K_NO_WAIT);

			/* reset the buffer (it was copied to the msgq) */
			rx_buf_pos = 0;
		} else if (rx_buf_pos < (sizeof(rx_buf) - 1)) {
			rx_buf[rx_buf_pos++] = c;
		}
		/* else: characters beyond buffer size are dropped */
	}
}

/*
 * Print a null-terminated string character by character to the UART interface
 */
void print_uart(char *buf)
{
	int msg_len = strlen(buf);

	for (int i = 0; i < msg_len; i++) {
		uart_poll_out(nus_uart, buf[i]);
	}
}

static void uart_dtr_wait(const struct device *dev)
{
	if (IS_ENABLED(CONFIG_UART_LINE_CTRL)) {
		int dtr, err;

		while (true) {
			err = uart_line_ctrl_get(dev, UART_LINE_CTRL_DTR, &dtr);
			if (err == -ENOSYS || err == -ENOTSUP) {
				break;
			}
			if (dtr) {
				break;
			}
			/* Give CPU resources to low priority threads. */
			k_sleep(K_MSEC(100));
		}
	}
}

static void ipc_host_receive(const uint8_t *data, size_t len, void *context)
{
	int recv_len;
	const struct device *uart_dev = context;

	if (!data || (len == 0)) {
		return;
	}

	recv_len = ring_buf_put(&tx_ringbuf, data, len);
	if (recv_len < len) {
		LOG_INF("TX ring buffer full. Dropping %d bytes", len - recv_len);
	}

	uart_irq_tx_enable(uart_dev);
}

static void uart_tx_procces(const struct device *dev, const struct uart_irq_context *uart_ctrl)
{
	int err;
	int send_len = 0;
	uint8_t *data;

	send_len  = ring_buf_get_claim(uart_ctrl->tx_buf, &data, uart_ctrl->tx_buf->size);
	if (send_len) {
		if (IS_ENABLED(CONFIG_UART_LINE_CTRL)) {
			uart_dtr_wait(dev);
		}

		send_len = uart_fifo_fill(dev, data, send_len);
		err = ring_buf_get_finish(uart_ctrl->tx_buf, send_len);
		__ASSERT_NO_MSG(err == 0);
	} else {
		uart_irq_tx_disable(dev);
	}
}

static void uart_rx_process(const struct device *dev, const struct uart_irq_context *uart_ctrl)
{
	int recv_len = 0;
	uint8_t *data;

	recv_len = ring_buf_put_claim(uart_ctrl->rx_buf, &data, uart_ctrl->rx_buf->size);
	if (recv_len) {
		recv_len = uart_fifo_read(dev, data, recv_len);
		if (recv_len < 0) {
			LOG_ERR("Failed to read UART FIFO, err %d", recv_len);
			recv_len = 0;
		} else {
			ring_buf_put_finish(uart_ctrl->rx_buf, recv_len);
		}

		if (recv_len) {
			k_sem_give(uart_ctrl->write_sem);
		}
	}
}

static void uart_irq_handler(const struct device *dev, void *user_data)
{
	const struct uart_irq_context *uart_ctrl = user_data;
	
	while (uart_irq_update(dev) && uart_irq_is_pending(dev)) {
		if (uart_irq_rx_ready(dev)) {
			uart_rx_process(dev, uart_ctrl);
		}

		if (uart_irq_tx_ready(dev)) {
			uart_tx_procces(dev, uart_ctrl);
		}
	}
}

static void connected(struct bt_conn *conn, uint8_t err)
{
	char addr[BT_ADDR_LE_STR_LEN];

	if (err) {
		LOG_ERR("Connection failed (err %u)", err);
		return;
	}

	bt_addr_le_to_str(bt_conn_get_dst(conn), addr, sizeof(addr));
	LOG_INF("Connected %s", addr);

	current_conn = bt_conn_ref(conn);

	dk_set_led_on(CON_STATUS_LED);
}

static void disconnected(struct bt_conn *conn, uint8_t reason)
{
	char addr[BT_ADDR_LE_STR_LEN];

	bt_addr_le_to_str(bt_conn_get_dst(conn), addr, sizeof(addr));

	LOG_INF("Disconnected: %s (reason %u)", addr, reason);

	if (auth_conn) {
		bt_conn_unref(auth_conn);
		auth_conn = NULL;
	}

	if (current_conn) {
		bt_conn_unref(current_conn);
		current_conn = NULL;
		dk_set_led_off(CON_STATUS_LED);
	}
}

#ifdef CONFIG_BT_NUS_SECURITY_ENABLED
static void security_changed(struct bt_conn *conn, bt_security_t level,
			     enum bt_security_err err)
{
	char addr[BT_ADDR_LE_STR_LEN];

	bt_addr_le_to_str(bt_conn_get_dst(conn), addr, sizeof(addr));

	if (!err) {
		LOG_INF("Security changed: %s level %u", addr, level);
	} else {
		LOG_WRN("Security failed: %s level %u err %d", addr,
			level, err);
	}
}
#endif

BT_CONN_CB_DEFINE(conn_callbacks) = {
	.connected    = connected,
	.disconnected = disconnected,
#ifdef CONFIG_BT_NUS_SECURITY_ENABLED
	.security_changed = security_changed,
#endif
};

#if defined(CONFIG_BT_NUS_SECURITY_ENABLED)
static void auth_passkey_display(struct bt_conn *conn, unsigned int passkey)
{
	char addr[BT_ADDR_LE_STR_LEN];

	bt_addr_le_to_str(bt_conn_get_dst(conn), addr, sizeof(addr));

	LOG_INF("Passkey for %s: %06u", addr, passkey);
}

static void auth_passkey_confirm(struct bt_conn *conn, unsigned int passkey)
{
	char addr[BT_ADDR_LE_STR_LEN];

	auth_conn = bt_conn_ref(conn);

	bt_addr_le_to_str(bt_conn_get_dst(conn), addr, sizeof(addr));

	LOG_INF("Passkey for %s: %06u", addr, passkey);
	LOG_INF("Press Button 1 to confirm, Button 2 to reject.");
}


static void auth_cancel(struct bt_conn *conn)
{
	char addr[BT_ADDR_LE_STR_LEN];

	bt_addr_le_to_str(bt_conn_get_dst(conn), addr, sizeof(addr));

	LOG_INF("Pairing cancelled: %s", addr);
}


static void pairing_complete(struct bt_conn *conn, bool bonded)
{
	char addr[BT_ADDR_LE_STR_LEN];

	bt_addr_le_to_str(bt_conn_get_dst(conn), addr, sizeof(addr));

	LOG_INF("Pairing completed: %s, bonded: %d", addr, bonded);
}


static void pairing_failed(struct bt_conn *conn, enum bt_security_err reason)
{
	char addr[BT_ADDR_LE_STR_LEN];

	bt_addr_le_to_str(bt_conn_get_dst(conn), addr, sizeof(addr));

	LOG_INF("Pairing failed conn: %s, reason %d", addr, reason);
}


static struct bt_conn_auth_cb conn_auth_callbacks = {
	.passkey_display = auth_passkey_display,
	.passkey_confirm = auth_passkey_confirm,
	.cancel = auth_cancel,
};

static struct bt_conn_auth_info_cb conn_auth_info_callbacks = {
	.pairing_complete = pairing_complete,
	.pairing_failed = pairing_failed
};
#else
static struct bt_conn_auth_cb conn_auth_callbacks;
static struct bt_conn_auth_info_cb conn_auth_info_callbacks;
#endif

static void bt_receive_cb(struct bt_conn *conn, const uint8_t *const data,
			  uint16_t len)
{
	char addr[BT_ADDR_LE_STR_LEN] = {0};

	bt_addr_le_to_str(bt_conn_get_dst(conn), addr, ARRAY_SIZE(addr));

	LOG_INF("Received data from: %s", addr);

	for (int i = 0; i < len; i++) {
		uart_poll_out(nus_uart, data[i]);
	}
}

static struct bt_nus_cb nus_cb = {
	.received = bt_receive_cb,
};

void error(void)
{
	dk_set_leds_state(DK_ALL_LEDS_MSK, DK_NO_LEDS_MSK);

	while (true) {
		/* Spin for ever */
		k_sleep(K_MSEC(1000));
	}
}

#ifdef CONFIG_BT_NUS_SECURITY_ENABLED
static void num_comp_reply(bool accept)
{
	if (accept) {
		bt_conn_auth_passkey_confirm(auth_conn);
		LOG_INF("Numeric Match, conn %p", (void *)auth_conn);
	} else {
		bt_conn_auth_cancel(auth_conn);
		LOG_INF("Numeric Reject, conn %p", (void *)auth_conn);
	}

	bt_conn_unref(auth_conn);
	auth_conn = NULL;
}

void button_changed(uint32_t button_state, uint32_t has_changed)
{
	uint32_t buttons = button_state & has_changed;

	if (auth_conn) {
		if (buttons & KEY_PASSKEY_ACCEPT) {
			num_comp_reply(true);
		}

		if (buttons & KEY_PASSKEY_REJECT) {
			num_comp_reply(false);
		}
	}
}
#endif /* CONFIG_BT_NUS_SECURITY_ENABLED */

static void configure_gpio(void)
{
	int err;

#ifdef CONFIG_BT_NUS_SECURITY_ENABLED
	err = dk_buttons_init(button_changed);
	if (err) {
		LOG_ERR("Cannot init buttons (err: %d)", err);
	}
#endif /* CONFIG_BT_NUS_SECURITY_ENABLED */

	err = dk_leds_init();
	if (err) {
		LOG_ERR("Cannot init LEDs (err: %d)", err);
	}
}

int main(void)
{
	int blink_status = 0;
	int err = 0;
	static const struct device *gpio_dev;
	int pin_status;
	struct uart_config user_uart_config;

	configure_gpio();

	/* Configure the pin */
	gpio_dev = DEVICE_DT_GET(DT_NODELABEL(gpio1));
	err = gpio_pin_configure(gpio_dev, 5, GPIO_INPUT | GPIO_PULL_DOWN);
	
	pin_status = gpio_pin_get(gpio_dev, 5);
	if(pin_status==1)	//P1.05 is high
	{
		dtm_ready = true;
		printk("P1.05 is high\n");
	}

	if(dtm_ready)
	{
		const struct device *dev = DEVICE_DT_GET(DT_CHOSEN(ncs_remote_shell_uart));
		uint32_t baudrate = 0;	

		printk("dtm run\n");

		if (!device_is_ready(dev)) {
			LOG_ERR("Device not ready");
			return 0;
		}

		if (IS_ENABLED(CONFIG_USB_DEVICE_STACK)) {
			err = usb_enable(NULL);
			if (err != 0) {
				LOG_ERR("Failed to enable USB, err %d", err);
				return 0;
			}
		}

		if (IS_ENABLED(CONFIG_UART_LINE_CTRL)) {
			LOG_INF("Wait for DTR");

			uart_dtr_wait(dev);

			LOG_INF("DTR set");

			/* They are optional, we use them to test the interrupt endpoint */
			err = uart_line_ctrl_set(dev, UART_LINE_CTRL_DCD, 1);
			if (err) {
				LOG_WRN("Failed to set DCD, err %d", err);
			}

			err = uart_line_ctrl_set(dev, UART_LINE_CTRL_DSR, 1);
			if (err) {
				LOG_WRN("Failed to set DSR, err %d", err);
			}

			/* Wait 1 sec for the host to do all settings */
			k_busy_wait(HOST_WAIT_TIME);

			err = uart_line_ctrl_get(dev, UART_LINE_CTRL_BAUD_RATE, &baudrate);
			if (err) {
				LOG_WRN("Failed to get baudrate, err %d", err);
			} else {
				LOG_INF("Baudrate detected: %d", baudrate);
			}
		}

		uart_irq_callback_user_data_set(dev, uart_irq_handler, (void *)&uart_context);

		/* Enable rx interrupts */
		uart_irq_rx_enable(dev);

		err = shell_ipc_host_init(ipc_host_receive, (void *)dev);
		if (err) {
			LOG_ERR("Shell IPC host initialization failed, err %d", err);
			return 0;
		}

		for (;;) {
			uint8_t *data;
			uint32_t data_size;

			k_sem_take(&shell_ipc_write_sem, K_FOREVER);

			data_size = ring_buf_get_claim(&rx_ringbuf, &data, rx_ringbuf.size);

			if (data_size) {
				data_size = shell_ipc_host_write(data, data_size);
				if (data_size >= 0) {
					LOG_DBG("Sent %d bytes", data_size);
					ring_buf_get_finish(&rx_ringbuf, data_size);
				} else {
					LOG_INF("Failed to send %d bytes (%d error)",
						data_size, data_size);
				}
			}
		}
	}
	else
	{
		printk("ble run\n");

		if (!device_is_ready(nus_uart)) {
			LOG_ERR("Device not ready");
			return 0;
		}

		(void)uart_config_get(nus_uart, &user_uart_config);
		//printk("baudrate : %d\n", user_uart_config.baudrate);
		user_uart_config.baudrate=115200;
		(void)uart_configure(nus_uart, &user_uart_config);

		/* configure interrupt and callback to receive data */
		err = uart_irq_callback_user_data_set(nus_uart, nus_serial_cb, NULL);

		if (err < 0) {
			if (err == -ENOTSUP) {
				printk("Interrupt-driven UART API support not enabled\n");
			} else if (err == -ENOSYS) {
				printk("UART device does not support interrupt-driven API\n");
			} else {
				printk("Error setting UART callback: %d\n", err);
			}
			return 0;
		}
		uart_irq_rx_enable(nus_uart);

		if (IS_ENABLED(CONFIG_BT_NUS_SECURITY_ENABLED)) {
			err = bt_conn_auth_cb_register(&conn_auth_callbacks);
			if (err) {
				printk("Failed to register authorization callbacks.\n");
				return 0;
			}

			err = bt_conn_auth_info_cb_register(&conn_auth_info_callbacks);
			if (err) {
				printk("Failed to register authorization info callbacks.\n");
				return 0;
			}
		}

		err = bt_enable(NULL);
		if (err) {
			error();
		}

		LOG_INF("Bluetooth initialized");

		k_sem_give(&ble_init_ok);

		if (IS_ENABLED(CONFIG_SETTINGS)) {
			settings_load();
		}

		err = bt_nus_init(&nus_cb);
		if (err) {
			LOG_ERR("Failed to initialize UART service (err: %d)", err);
			return 0;
		}

		err = bt_le_adv_start(BT_LE_ADV_CONN, ad, ARRAY_SIZE(ad), sd,
					ARRAY_SIZE(sd));
		if (err) {
			LOG_ERR("Advertising failed to start (err %d)", err);
			return 0;
		}

		for (;;) {
			dk_set_led(RUN_STATUS_LED, (++blink_status) % 2);
			k_sleep(K_MSEC(RUN_LED_BLINK_INTERVAL));
		}
	}
}

void ble_write_thread(void)
{
	char tx_buf[MSG_SIZE];

	/* Don't go any further until BLE is initialized */
	k_sem_take(&ble_init_ok, K_FOREVER);

	while (k_msgq_get(&uart_msgq, &tx_buf, K_FOREVER) == 0) {
		if (bt_nus_send(NULL, tx_buf, sizeof(tx_buf))) {
			LOG_WRN("Failed to send data over BLE connection");
		}
		//print_uart("Echo: ");
		//print_uart(tx_buf);
		//print_uart("\r\n");
	}
}

K_THREAD_DEFINE(ble_write_thread_id, STACKSIZE, ble_write_thread, NULL, NULL,
		NULL, PRIORITY, 0, 0);

/** @brief Allow access to specific GPIOs for the network core.
 *
 * Function is executed very early during system initialization to make sure
 * that the network core is not started yet. More pins can be added if the
 * network core needs them.
 */
static int network_gpio_allow(void)
{
	/* When the use of the low frequency crystal oscillator (LFXO) is
	 * enabled, do not modify the configuration of the pins P0.00 (XL1)
	 * and P0.01 (XL2), as they need to stay configured with the value
	 * Peripheral.
	 */
//	uint32_t start_pin = (IS_ENABLED(CONFIG_SOC_ENABLE_LFXO) ? 2 : 0);

	/* Allow the network core to use all GPIOs. */
//	for (uint32_t i = start_pin; i < P0_PIN_NUM; i++) {
//		NRF_P0_S->PIN_CNF[i] = (GPIO_PIN_CNF_MCUSEL_NetworkMCU <<
//					GPIO_PIN_CNF_MCUSEL_Pos);
//	}

//	for (uint32_t i = 0; i < P1_PIN_NUM; i++) {
//		NRF_P1_S->PIN_CNF[i] = (GPIO_PIN_CNF_MCUSEL_NetworkMCU <<
//					GPIO_PIN_CNF_MCUSEL_Pos);
//	}

	NRF_P1_S->PIN_CNF[4] = (GPIO_PIN_CNF_MCUSEL_NetworkMCU << GPIO_PIN_CNF_MCUSEL_Pos);	//P1.04

	return 0;
}

SYS_INIT(network_gpio_allow, PRE_KERNEL_1, CONFIG_KERNEL_INIT_PRIORITY_OBJECTS);